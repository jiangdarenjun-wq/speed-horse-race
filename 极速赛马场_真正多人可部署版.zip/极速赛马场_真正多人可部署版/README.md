# 极速赛马场｜真正多人可部署版

这是一个**纯虚拟金币娱乐版**多人赛马网站，不支持真实充值、提现或现金下注。

## 已包含

- 用户注册 / 登录
- bcrypt 密码哈希
- JWT 登录状态
- 每个用户独立虚拟金币
- 5 匹马
- 服务端随机速度与冠军
- 多人实时大厅（Socket.IO）
- 虚拟金币投入与中奖结算
- 个人比赛记录
- 全球排行榜
- SQLite 数据库
- Docker / Docker Compose
- 手机端自适应页面

## 最简单的部署方式

需要一台支持 Docker 的服务器（例如任意常见云服务器）。

1. 上传整个项目。
2. 执行：

```bash
docker compose up -d --build
```

3. 浏览器打开：

```text
http://你的服务器IP:3000
```

生产环境请设置强随机的 `JWT_SECRET` 和 `ADMIN_KEY`，并通过 HTTPS 反向代理（Nginx/Caddy）访问。

## 不建议直接放到 Netlify

Netlify 静态托管不能单独承载本项目的 Node.js + SQLite + WebSocket 后端。
如果使用 Netlify，只适合作为前端；真正多人实时功能仍需要独立后端服务器。

## 数据

默认使用 SQLite，数据库文件为 `data.sqlite`。Docker Compose 已通过 volume 持久化。

## 管理接口

管理员统计接口：

`GET /api/admin/stats`

请求头：

`x-admin-key: 你的ADMIN_KEY`

## 重要

本项目只设计为虚拟金币娱乐游戏。不要接入真实货币充值、提现、现金下注或其他赌博支付功能；如果要公开运营，应先确认所在地适用的法律和平台规则。
