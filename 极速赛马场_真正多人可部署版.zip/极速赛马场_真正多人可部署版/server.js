const express = require("express");
const http = require("http");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "change-this-secret-in-production";
const ADMIN_KEY = process.env.ADMIN_KEY || "change-admin-key";
const START_COINS = 10000;
const HORSES = ["赤焰", "闪电", "风暴", "黑影", "黄金"];

const db = new Database(process.env.DB_FILE || path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 coins INTEGER NOT NULL DEFAULT ${START_COINS},
 wins INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS races(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 winner TEXT NOT NULL,
 speeds_json TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bets(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 race_id INTEGER NOT NULL,
 horse TEXT NOT NULL,
 amount INTEGER NOT NULL,
 reward INTEGER NOT NULL DEFAULT 0,
 won INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(race_id) REFERENCES races(id)
);
`);

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function tokenFor(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  try {
    const raw = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    req.user = jwt.verify(raw, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "请先登录" });
  }
}
function publicUser(id) {
  return db.prepare("SELECT id, username, coins, wins, created_at FROM users WHERE id=?").get(id);
}
function makeRace() {
  const speeds = Object.fromEntries(HORSES.map(h => [h, Math.floor(70 + Math.random() * 31)]));
  const winner = HORSES.reduce((a,b) => speeds[b] > speeds[a] ? b : a, HORSES[0]);
  const race = db.prepare("INSERT INTO races(winner,speeds_json) VALUES(?,?)").run(winner, JSON.stringify(speeds));
  return { id: race.lastInsertRowid, winner, speeds };
}

let currentRace = null;
let nextRaceAt = Date.now() + 12000;

function broadcastRaceState() {
  io.emit("race:state", { currentRace, nextRaceAt, horses: HORSES });
}
function runRace() {
  const race = makeRace();
  currentRace = race;
  nextRaceAt = Date.now() + 15000;
  const allBets = db.prepare("SELECT * FROM bets WHERE race_id=?").all(race.id);
  const payout = db.transaction(() => {
    for (const bet of allBets) {
      if (bet.horse === race.winner) {
        const reward = bet.amount * 4;
        db.prepare("UPDATE bets SET won=1,reward=? WHERE id=?").run(reward, bet.id);
        db.prepare("UPDATE users SET coins=coins+?, wins=wins+1 WHERE id=?").run(reward, bet.user_id);
      }
    }
  });
  payout();
  io.emit("race:result", race);
  io.emit("leaderboard", leaderboard());
  setTimeout(() => {
    currentRace = null;
    broadcastRaceState();
    setTimeout(runRace, 15000);
  }, 7000);
}

function leaderboard() {
  return db.prepare("SELECT username, coins, wins FROM users ORDER BY coins DESC, wins DESC LIMIT 50").all();
}

app.post("/api/register", async (req,res)=>{
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[\u4e00-\u9fa5A-Za-z0-9_]{2,20}$/.test(username))
    return res.status(400).json({error:"用户名需为2-20位中文、字母、数字或下划线"});
  if (password.length < 6) return res.status(400).json({error:"密码至少6位"});
  try {
    const hash = await bcrypt.hash(password, 10);
    const info = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username,hash);
    const user = publicUser(info.lastInsertRowid);
    res.json({token:tokenFor(user), user});
  } catch {
    res.status(409).json({error:"用户名已存在"});
  }
});

app.post("/api/login", async (req,res)=>{
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !(await bcrypt.compare(password,user.password_hash)))
    return res.status(401).json({error:"用户名或密码错误"});
  res.json({token:tokenFor(user), user:publicUser(user.id)});
});

app.get("/api/me", auth, (req,res)=>res.json(publicUser(req.user.id)));
app.get("/api/leaderboard", (req,res)=>res.json(leaderboard()));

app.get("/api/history", auth, (req,res)=>{
  const rows = db.prepare(`
    SELECT b.id,b.race_id,b.horse,b.amount,b.reward,b.won,r.winner,r.created_at
    FROM bets b JOIN races r ON r.id=b.race_id
    WHERE b.user_id=? ORDER BY b.id DESC LIMIT 50
  `).all(req.user.id);
  res.json(rows);
});

app.post("/api/bet", auth, (req,res)=>{
  const raceId = Number(req.body.raceId);
  const horse = String(req.body.horse || "");
  const amount = Math.floor(Number(req.body.amount));
  if (!HORSES.includes(horse)) return res.status(400).json({error:"请选择有效的马"});
  if (!Number.isInteger(amount) || amount < 1 || amount > 5000)
    return res.status(400).json({error:"虚拟金币投入范围为1-5000"});
  if (!currentRace || currentRace.id !== raceId)
    return res.status(400).json({error:"本局已经结束或尚未开放"});
  const user = publicUser(req.user.id);
  if (user.coins < amount) return res.status(400).json({error:"虚拟金币不足"});
  db.prepare("UPDATE users SET coins=coins-? WHERE id=?").run(amount,user.id);
  db.prepare("INSERT INTO bets(user_id,race_id,horse,amount) VALUES(?,?,?,?)")
    .run(user.id,raceId,horse,amount);
  res.json({user:publicUser(user.id)});
});

app.get("/api/admin/stats",(req,res)=>{
  if (req.headers["x-admin-key"] !== ADMIN_KEY) return res.status(403).json({error:"无权限"});
  res.json({
    users: db.prepare("SELECT COUNT(*) c FROM users").get().c,
    races: db.prepare("SELECT COUNT(*) c FROM races").get().c,
    bets: db.prepare("SELECT COUNT(*) c FROM bets").get().c,
    virtualCoins: db.prepare("SELECT COALESCE(SUM(coins),0) c FROM users").get().c
  });
});

io.on("connection", socket=>{
  socket.emit("race:state",{currentRace,nextRaceAt,horses:HORSES});
  socket.emit("leaderboard",leaderboard());
});

server.listen(PORT, ()=>{
  console.log(`Speed Horse Race running on http://localhost:${PORT}`);
  setTimeout(runRace, 3000);
});